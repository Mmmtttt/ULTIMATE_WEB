# 漫画导入测试数据生成器

运行：

```bash
python generate_sample_imports.py --output ./sample_imports_out
```

会生成：

- 一个测试目录 `sample_imports_out/`
- 一个整包压缩文件 `sample_imports_out.zip`

覆盖场景：

- 作者层明确，作品分散在多个子目录
- 没有作者信息，只有作品层
- zip 多层嵌套压缩包
- 可选 7z / rar（取决于本机依赖）
