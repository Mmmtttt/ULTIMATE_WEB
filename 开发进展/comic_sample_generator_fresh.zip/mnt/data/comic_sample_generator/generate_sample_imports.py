#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path
import zipfile


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def write_fake_image(path: Path, label: str) -> None:
    ensure_dir(path.parent)
    # Minimal valid-ish PNG signature + text payload for testing file presence.
    payload = b"\x89PNG\r\n\x1a\n" + (f"FAKE_IMAGE:{label}\n".encode("utf-8"))
    path.write_bytes(payload)


def make_chapter_images(base: Path, chapters: int = 2, pages: int = 3) -> None:
    for c in range(1, chapters + 1):
        chap = base / f"Chapter_{c:02d}"
        ensure_dir(chap)
        for p in range(1, pages + 1):
            write_fake_image(chap / f"{p:03d}.png", f"{base.name}-c{c}-p{p}")


def zip_dir(src: Path, dst_zip: Path) -> None:
    ensure_dir(dst_zip.parent)
    with zipfile.ZipFile(dst_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for file in src.rglob("*"):
            zf.write(file, file.relative_to(src.parent))


def try_make_7z(src: Path, dst_7z: Path) -> bool:
    try:
        import py7zr  # type: ignore
    except Exception:
        return False
    ensure_dir(dst_7z.parent)
    with py7zr.SevenZipFile(dst_7z, "w") as zf:
        for file in src.rglob("*"):
            zf.write(file, file.relative_to(src.parent).as_posix())
    return True


def try_make_rar(src: Path, dst_rar: Path) -> bool:
    rar = shutil.which("rar")
    if not rar:
        return False
    ensure_dir(dst_rar.parent)
    cmd = [rar, "a", str(dst_rar), str(src)]
    completed = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return completed.returncode == 0


def build_dataset(out_dir: Path) -> None:
    if out_dir.exists():
        shutil.rmtree(out_dir)
    ensure_dir(out_dir)

    # Case 1: explicit author folders, works spread across descendants.
    a1 = out_dir / "case_author_grouped" / "作者1"
    make_chapter_images(a1 / "2020" / "作品1")
    make_chapter_images(a1 / "2020" / "作品2")
    make_chapter_images(a1 / "漫画平台1" / "2021" / "作品3")
    make_chapter_images(a1 / "漫画平台1" / "2021" / "作品4")

    a2 = out_dir / "case_author_grouped" / "作者2"
    make_chapter_images(a2 / "平台A" / "作品A")
    make_chapter_images(a2 / "平台B" / "2022" / "作品B")

    # Case 2: no author info.
    no_author = out_dir / "case_no_author" / "2024合集"
    make_chapter_images(no_author / "作品甲")
    make_chapter_images(no_author / "作品乙")

    # Case 3: nested archives source folders.
    nested_src = out_dir / "_build_nested"
    inner = nested_src / "作者3" / "站点X" / "2023" / "作品内层压缩包"
    make_chapter_images(inner)
    zip_dir(inner, nested_src / "inner_work.zip")
    if inner.exists():
        shutil.rmtree(inner)

    outer_pack = out_dir / "case_nested_archives"
    ensure_dir(outer_pack)
    zip_dir(nested_src, outer_pack / "外层合集.zip")
    made_7z = try_make_7z(nested_src, outer_pack / "外层合集.7z")
    made_rar = try_make_rar(nested_src, outer_pack / "外层合集.rar")

    notes = [
        "这是自动生成的漫画导入测试数据。",
        "包含文件夹导入、zip 导入、多层嵌套压缩包等场景。",
        f"7z 已生成: {'是' if made_7z else '否（未安装 py7zr）'}",
        f"rar 已生成: {'是' if made_rar else '否（未安装 rar 命令）'}",
    ]
    (out_dir / "README.txt").write_text("\n".join(notes), encoding="utf-8")

    if nested_src.exists():
        shutil.rmtree(nested_src)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate sample comic import archives and folders.")
    parser.add_argument("--output", default="sample_imports_out", help="Output directory")
    args = parser.parse_args()

    out_dir = Path(args.output).resolve()
    build_dataset(out_dir)

    zip_path = out_dir.with_suffix(".zip")
    if zip_path.exists():
        zip_path.unlink()
    zip_dir(out_dir, zip_path)

    print(f"Generated dataset: {out_dir}")
    print(f"Generated zip: {zip_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
